# DAT Load Extractor v3.0.0

Exports DAT One load searches — and, unlike v2, everything behind each load:
route and stops, rate and market rates, truck and equipment, contact details,
company identifiers, and the full office profile from the DAT Directory.

Everything needed to run is in this folder. Nothing else to download.

---

## What's in here

| Item | Purpose |
|---|---|
| `dat-load-extractor-v2/` | The Chrome extension (load this folder into Chrome) |
| `server.py` | Local helper server — only needed for **Distributed Auto-Pilot** |
| `start-server.bat` | One-click server launcher for Windows |
| `start-server.sh` | One-click server launcher for macOS / Linux |
| `requirements.txt` | Python dependencies (installed automatically by the launchers) |
| `config.json` | Server settings (concurrency, batch size) |
| `DEEP-EXTRACTION.md` | Technical notes on how the deep extraction works |

---

## Step 1 — Install the extension (required)

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode** (toggle, top right)
3. Click **Load unpacked**
4. Select the **`dat-load-extractor-v2`** folder inside this folder
5. "DAT Load Extractor V2 — 3.0.0" appears in the list

Pin it: click the puzzle-piece icon in Chrome's toolbar, then the pin next to
DAT Load Extractor. Clicking the icon opens it in Chrome's side panel.

> Keep the extension where you unzipped it. If you move the folder later,
> Chrome treats it as a new extension and you'll need to load it again.

## Step 2 — Log in to DAT One

Open <https://one.dat.com/search-loads> in the same Chrome profile and sign in.
The extension reads the page you're already logged into — it never handles your
password and never stores credentials.

## Step 3 — Extract

1. Run a search on DAT One (origin, destination, equipment type, load type)
2. Open the extension panel
3. Leave **Deep Extraction** on
4. Click **Start Extraction**

The panel shows live progress: loads found, processed, complete / partial /
failed, fields extracted and retries, plus which sections were visited.

When it finishes, export as **TXT**, **CSV**, **JSON** or **Excel (.xlsx)**.

---

## Step 4 — Start the server (only for Distributed Auto-Pilot)

Manual extraction works with no server running. The server is only needed for
the **Distributed Auto-Pilot** tab, which crawls many origin/destination/
equipment combinations across multiple tabs and saves results to disk.

- **Windows** — double-click `start-server.bat`
- **macOS / Linux** — run `./start-server.sh` in a terminal
  (first time only: `chmod +x start-server.sh`)

First run creates a `.venv` folder and installs the dependencies — that takes a
minute and needs internet. After that it starts instantly and works offline.

Leave the window open while crawling. The extension panel will show
**Server Online**. Press `Ctrl+C` to stop.

Requires **Python 3.9 or newer** — <https://www.python.org/downloads/>
(on Windows, tick *"Add python.exe to PATH"* during install).

---

## What gets extracted

**From the results table (as in v2):** timestamp, age, rate, rate per mile, trip
miles, origin, destination, deadhead origin/destination, equipment type, weight,
length, load type, company, factoring, row status, capture key, list index,
search criteria, docket, DOT number, credit score.

**New in v3, from each load's detail view:**

| Group | Fields |
|---|---|
| Load | load ID / number / status, load type, commodity, reference ID, pickup + delivery date and time |
| Route | ordered stops with deadhead miles and dates, origin, destination, total miles, route distance |
| Truck | truck type, equipment, trailer, length, weight, capacity, dimensions, special requirements |
| Rate | rate total, total trip, rate per mile, total cost, spot rate + per mile, rate basis, market, rate range (low/high, per mile), contract rate, line haul, fuel, tolls, detention, accessorials |
| Company | name, DBA, authority name, MC number, docket, DOT number, credit score, days to pay, company/entity type, operating status, insurance carrier + policy + coverage + dates, ratings |
| Contact | name, title, phone, mobile, fax, email, website, plus every email and phone found |
| Office | office name, full address split into line 1 / line 2 / city / state / ZIP / country, phone, fax, email, hours |

Anything DAT shows that isn't one of the fields above is still kept, under
**Additional Data** — so a future DAT redesign adds unknown fields rather than
losing them.

Every load also carries an extraction record: `complete`, `partial` or `failed`,
which sections were visited or failed, how many fields were captured, retries,
warnings and errors. One load failing never stops the rest of the batch.

### Export formats

- **CSV / Excel** — one row per load. The original v2 columns come first, in the
  same order, followed by the deep columns.
- **JSON** — full nested structure per load: `summary`, `details`, `route`,
  `truck`, `company`, `contact`, `office`, `rate`, `additionalData`, `extraction`.
- **TXT** — a readable report with a block per load.

---

## Verifying coverage

Open the **Load Inspector** at the bottom of the panel, pick a load, and compare
it against what DAT shows in the browser. Each group is listed with its captured
values plus the extraction metadata.

If something visible on the page is missing from the mapped fields, check
**Additional Data** — it will usually be there under a generated name, which
means it was captured but not yet mapped to a named column.

---

## Settings

**Speed Mode** — Normal / Fast / Ultra. Controls scroll and wait timings while
walking the results table. Ultra is fastest; if rows come back empty on a slow
connection, drop to Normal.

**Deep Extraction** — on by default.
- *Traversal depth* (default 3) — how many levels of nested tabs/panels to open.
- *Max reveals per load* (default 26) — safety cap on clicks per load.
- *Retries* (default 1) — retry attempts for a load whose detail view fails.
- Turning it **off** returns exactly the v2 behaviour and the v2 columns.

---

## What the extension will and won't click

While exploring a load it opens tabs, accordions, expanders, "View Route" and
"more details" style controls.

It never clicks anything that acts on your behalf — no book, bid, offer, call,
connect-email, send, save, delete, report, share, submit or apply, and it never
follows a link that navigates away or opens a tab on its own.

---

## Troubleshooting

**"Open one.dat.com search loads first"** — the active tab isn't a DAT page. Open
your DAT One search and try again.

**Extraction returns 0 loads** — make sure the search has finished rendering
rows, then re-run. If the page was left idle a long time, refresh it first.

**Fields are blank for every load** — you're probably signed out. Refresh
one.dat.com, sign in, and re-run.

**"Server Offline (Run server.py)"** — only matters for Distributed Auto-Pilot.
Start `start-server.bat` / `start-server.sh`. Manual extraction is unaffected.

**Server won't start** — Python 3 is missing or not on PATH. Install it from
python.org (tick *"Add python.exe to PATH"* on Windows) and run the launcher
again.

**Extraction feels slow** — each load's detail view is opened and read, so a
large result set takes time. Lower *Max reveals per load*, or switch Deep
Extraction off for a quick summary-only pass.

---

## Privacy

Everything runs locally in your browser. Nothing is uploaded anywhere. The
optional server listens only on `127.0.0.1` (your own machine) and writes its
crawl results next to `server.py`.
