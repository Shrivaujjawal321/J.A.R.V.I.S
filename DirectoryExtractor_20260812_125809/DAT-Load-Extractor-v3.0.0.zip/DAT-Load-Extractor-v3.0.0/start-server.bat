@echo off
REM DAT Load Extractor v3 - server launcher (Windows)
REM Creates a virtual environment on first run, installs dependencies, starts the server.

cd /d "%~dp0"
title DAT Load Extractor - Server

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Python 3 was not found on this machine.
  echo   Install it from https://www.python.org/downloads/
  echo   and tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b 1
)

if not exist ".venv" (
  echo Creating virtual environment ^(first run only^)...
  python -m venv .venv
  if errorlevel 1 (
    echo Could not create the virtual environment.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"

echo Checking dependencies...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
if errorlevel 1 (
  echo.
  echo   Dependency install failed. Check your internet connection.
  echo.
  pause
  exit /b 1
)

echo.
echo   Server starting on http://127.0.0.1:5000
echo   Leave this window open while you use the extension.
echo   Press Ctrl+C to stop.
echo.
python server.py

pause
