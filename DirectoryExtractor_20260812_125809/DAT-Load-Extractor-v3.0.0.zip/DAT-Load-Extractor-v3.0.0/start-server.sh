#!/usr/bin/env bash
# DAT Load Extractor v3 - server launcher (macOS / Linux)
#
# Prefers an isolated virtual environment. Some Linux builds ship Python without
# the venv module, so this falls back to a user-level install rather than
# failing outright.
cd "$(dirname "$0")" || exit 1

PY=""
for candidate in python3 python; do
  if command -v "$candidate" >/dev/null 2>&1; then
    if "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
      PY="$candidate"
      break
    fi
  fi
done

if [ -z "$PY" ]; then
  echo
  echo "  Python 3.9 or newer was not found."
  echo "    macOS:  brew install python"
  echo "    Ubuntu: sudo apt install python3 python3-venv"
  echo
  exit 1
fi

deps_ok() {
  "$1" -c 'import flask, flask_cors, openpyxl, psutil' >/dev/null 2>&1
}

RUN_PY=""

# ── 1. Preferred: isolated virtual environment ──
if [ -x ".venv/bin/python" ]; then
  RUN_PY=".venv/bin/python"
else
  echo "Creating virtual environment (first run only)..."
  if "$PY" -m venv .venv >/dev/null 2>&1 && [ -x ".venv/bin/python" ]; then
    RUN_PY=".venv/bin/python"
  else
    rm -rf .venv
    echo "  (this Python has no venv module - using a user-level install instead)"
  fi
fi

if [ -n "$RUN_PY" ]; then
  echo "Checking dependencies..."
  "$RUN_PY" -m pip install --quiet --upgrade pip >/dev/null 2>&1
  if ! "$RUN_PY" -m pip install --quiet -r requirements.txt; then
    echo
    echo "  Dependency install failed. Check your internet connection."
    echo
    exit 1
  fi
fi

# ── 2. Fallback: system Python with a user-level install ──
if [ -z "$RUN_PY" ]; then
  RUN_PY="$PY"
  if ! deps_ok "$RUN_PY"; then
    echo "Installing dependencies for the current user..."
    if ! "$RUN_PY" -m pip install --quiet --user -r requirements.txt 2>/dev/null; then
      # Newer distributions mark the system Python as externally managed.
      "$RUN_PY" -m pip install --quiet --user --break-system-packages -r requirements.txt 2>/dev/null
    fi
  fi
  if ! deps_ok "$RUN_PY"; then
    echo
    echo "  Could not install the dependencies automatically."
    echo "  Install the venv module and run this script again:"
    echo
    echo "      sudo apt install python3-venv     # Debian / Ubuntu"
    echo
    echo "  Or install the packages yourself:"
    echo
    echo "      $RUN_PY -m pip install --user Flask flask-cors openpyxl psutil"
    echo
    exit 1
  fi
fi

echo
echo "  Server starting on http://127.0.0.1:5000"
echo "  Leave this window open while you use the extension."
echo "  Press Ctrl+C to stop."
echo
exec "$RUN_PY" server.py
