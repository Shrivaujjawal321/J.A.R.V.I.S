# Data Card — Steel Maintenance Wizard Flagship Dataset

**Dataset:** `steel-maintenance-flagship`
**Spine version:** 1.0.0
**Generated:** 2026-06-09
**Reference site:** `TATA_JSR` (synthetic Jamshedpur-style integrated steel plant)
**Purpose:** Ground-truth spine for the Tata Steel Round 2 Maintenance Wizard. Every downstream artifact (historian time-series export, RAG knowledge base, FMEA graph, eval set) is generated against this single source of truth.

---

## 1. What This Is

This is the **ground-truth spine** — the authoritative registry of assets, failure scenarios, and spare parts that all other dataset files reference. It is not the time-series itself; it is the physics-grounded specification from which a realistic historian export, a maintenance knowledge base, and labelled failure events are synthesized so they stay mutually consistent (a vibration spike in the time-series matches a bearing-spall scenario here, which matches a repair playbook in the RAG corpus, which consumes a spare part listed here).

Three top-level collections:

| Collection | Count | Description |
|---|---|---|
| `asset_registry` | 15 assets / 13 equipment classes | ISA-95-style asset IDs, fitted sensors with real normal/warning/alarm bands + sampling rates, applicable failure modes |
| `failure_scenario_catalog` | 48 scenarios (36 normal / 12 failure) | Labelled scenarios with degradation timelines, exact sensor signatures, control-system fault codes, root cause, playbook resolution, spares, downtime, cost, ISA-18.2 safety class |
| `spare_parts_master` | 44 parts | Part ID, name, fitted equipment classes, stock qty, lead time (weeks), unit cost (INR + USD) |

---

## 2. Equipment Classes Covered (13)

Rolling-mill work-roll bearing · mill gearbox · large induction motor + VFD · cooling/descaling pump · BF/sinter fan-blower · continuous-caster segment · continuous-caster mould · hot-strip-mill stand · raw-material conveyor · reheating furnace · EAF/BOF auxiliary hydraulics · ladle crane · AGC hydraulic servo-valve.

Spans the full process chain: raw-material handling → iron-making (BF) → sintering → steelmaking (EAF/BOF + ladle handling) → casting → reheating → hot rolling → cold rolling.

---

## 3. Physics Grounding & Standards Backbone

Every numeric threshold is traceable to a published standard or the research briefs (`research/machinery/17-20`, `research/domain/04-08`). Key examples:

- **Vibration:** ISO 10816-3:2009 / ISO 20816-3:2022 zone boundaries — Zone A/B ≤2.3 mm/s, Zone C warning 4.5 mm/s, Zone D trip 7.1 mm/s.
- **Bearing temperature:** ISO 15243:2017 — normal 40–70 °C, warning 85 °C, trip 100 °C.
- **Bearing failure progression:** 4-stage model — AE rises +6 dB (Stage 1, weeks before failure) → envelope BPFO 1.0→3.0 g (Stage 3) → temperature drift (Stage 4, lagging). Encoded in `degradation_timeline` + per-stage `sensor_signature`.
- **Motor:** NEMA MG1 phase imbalance (warn 2 %, alarm 5 %); IEC 60034-1 Class F winding (warn 145 °C, trip 155 °C); IEEE 1415 MCSA rotor-bar sidebands (-50 → -35 dBc); IEEE 43 polarisation index (<2.0 concern, <1.5 at-risk).
- **Hydraulics:** ISO 4406:2021 cleanliness codes — servo circuit ≤15/13/10 normal, 17/15/12 alarm.
- **Caster breakout:** EP2465622B1-grounded 3-sensor agreement (TC V-pattern ΔT >50 °C + oscillator friction >18 kN + mould level >12 mm) — single-sensor alone has >40 % false-alarm rate.
- **Crane rope:** ISO 4309:2017 discard criteria (≥5 % broken wires per lay; MFL retire at 300 mV).
- **Alarm priority:** ISA-18.2-2016 tiers P1 (critical/safety, <1 min) → P4 (advisory).
- **Cost/downtime:** `research/machinery/20` — caster breakout avg $860k/event, BF blower failure $4–8M+, roll change planned $11.2k vs unplanned $184k (16.4× multiplier), CRM cobble ~₹21 L/hr.

---

## 4. Input-Spec Coverage (PS sections 4.1–4.4)

The problem statement lists four distinct input categories. A submission that handles only documentation misses 75 % of the stated input space. This spine seeds all four:

| Input category | Spine coverage |
|---|---|
| **4.1 Operational & failure history** | `failure_scenario_catalog` — labelled failure events with root cause, downtime (planned vs unplanned), cost impact, ISO-14224-style failure modes per asset. Drives the operational/failure-log feed and supervised failure-prediction labels. |
| **4.2 Condition-monitoring sensor data** | `asset_registry.sensors` (tag, quantity, unit, normal/warning/alarm bands, sampling rate) + `sensor_signature` (normal → defect value, threshold_crossed, stage). Drives the synthetic historian time-series export (ISA-95 tags, multi-rate, OPC quality codes). |
| **4.3 Knowledge & documentation** | `correct_resolution` (steps from repair playbooks 19), `spare_parts_master`, standards references per sensor. Drives the RAG knowledge base (SOPs, manuals, failure reports) + FMEA knowledge graph. |
| **4.4 User interaction** | Scenario IDs + fault codes + root-cause/resolution pairs are the question-answer anchors for multi-turn diagnostic dialogue and eval-set construction (e.g. "F1 gearbox GMF alarming — what do I do?"). |

---

## 5. Class Balance (Deliberately Realistic)

**36 normal (75 %) / 12 failure (25 %).** Failures are rare in a real plant; a healthy-dominant dataset is the honest reflection and forces the modelling layer to handle imbalance correctly (per `research/domain/07`: **do NOT SMOTE** time-series — it creates physically impossible states like high vibration with low temperature, violating the friction-heat correlation; handle via `class_weight='balanced'` + isotonic calibration + anomaly-detection framing instead).

The 12 retained failures are spread one-per-class for diversity and include **all four safety-critical P1 events** (compressor surge, caster breakout, conveyor idler fire-risk, ladle-crane wire-rope failure) so the prioritization logic can be exercised against catastrophic-consequence modes.

The wider universe of failure modes (29 modes are declared across the asset registry; 12 are instantiated as scenarios) and the full 44-part spare catalog remain available so additional labelled events can be generated on demand without changing the spine schema.

---

## 6. Referential Integrity (validated)

- Every `failure_scenario_catalog.asset_id` resolves to an `asset_registry` entry (0 orphans).
- Every `spares_required.part_id` resolves to a `spare_parts_master` entry (0 missing).
- Every failure-scenario `failure_mode` is declared in its asset's `failure_modes` list.
- Every asset has at least one scenario.
- Every sensor referenced in a `sensor_signature` exists in that asset's `sensors` list.

---

## 7. SYNTHETIC — Physics-Grounded — Disclaimer

**This dataset is SYNTHETIC. No proprietary or real Tata Steel operational data is used.**

All asset names, tags, and the `TATA_JSR` site label are illustrative. Every numeric value (normal bands, thresholds, costs, lead times) is a **representative industry estimate** derived from public standards (ISO/IEC/NEMA/API/ISA), peer-reviewed literature, and practitioner sources compiled in the research briefs — not measured from any plant. Values tagged `[unverified]` in the source research carry that caveat forward.

**Site-specific baseline calibration is mandatory** before any threshold here is used for production alarming: absolute vibration/temperature/AE limits vary by machine size, speed, fluid grade, and installation class. The dataset's value is structural and physical *consistency* (the relationships between sensors, faults, resolutions, and costs are correct), not site-accurate absolute numbers.

---

## 8. Provenance

| Source brief | Used for |
|---|---|
| `research/machinery/17_common_sensors_placement_scada.md` | ISA-95 tag hierarchy, sensor placement, sampling rates, OPC quality, historian schema |
| `research/machinery/18_master_fault_reading_table.md` | Normal / defect / warning / alarm values per fault mode (sensor_signature) |
| `research/machinery/19_repair_playbooks.md` | correct_resolution steps, spares, time-to-repair |
| `research/machinery/20_cost_downtime_economics.md` | cost_impact, downtime_hours, planned-vs-unplanned multipliers |
| `research/domain/01,04,06,07,08` | judge intel, sensor taxonomy, input-spec mapping, class-balance discipline, quality rules |

---

## 9. Final Inventory (assembled 2026-06-09)

Full per-file breakdown is in `MANIFEST.md`. Headline counts:

| Tier | Files | Volume |
|---|---|---|
| Tabular (CSV) | 13 | 207,257 data rows (historian export = 131,040 rows × 73 cols) |
| Structured (JSONL) | 4 | 285 records (150 NL queries + 50 multi-turn + 60 troubleshooting + 25 RCA index) |
| Documents (Markdown) | 53 | 13 equipment manuals + 13 SOPs + 25 RCA reports + breakdown/OEM/shift-handover summaries + this card |
| Spine + scripts | 1 JSON + 4 PY | 15 assets · 51 scenarios · 44 spares; generators kept for provenance |

**Input-spec coverage:** PS §4.1 (operational & failure history), §4.2 (condition-monitoring sensor data), §4.3 (knowledge & documentation), and §4.4 (user interaction) are **all FULLY satisfied**, with an additional CMMS/alarm-management enrichment tier (`additional/`). See `MANIFEST.md` for the file→PS-item map.

---

## 10. Intended Uses

1. **Train / evaluate the Maintenance Wizard** — the flagship dataset is the primary corpus for the Tata Round-2 agentic Maintenance Wizard:
   - **Supervised failure prediction** from §4.2 historian (labels `fault_label`, `scenario_id`, `RUL_hours`) with the deliberately realistic 2.1 % failure rate (PdM-realistic imbalance; use `class_weight='balanced'` + calibration, **never SMOTE** time-series — §5).
   - **RAG knowledge base** from §4.3 (manuals + SOPs + RCA reports + spare catalog) — diagnosis, root-cause, repair-playbook retrieval.
   - **Eval set** from §4.4 (NL queries with `grounding_refs` + `expected_tools`, multi-turn diagnostic dialogues, troubleshooting prompts with reasoning chains and graded resolutions).
   - **FMEA / alarm-rationalization grounding** from `additional/` (ISA-18.2 alarm DB, work-order backlog, equipment master).
2. **Seed DataForge** — this dataset is the canonical seed for the DataForge data-quality engine: a known-good, cross-consistent, physics-grounded reference against which DataForge's audit/repair pipeline is exercised and benchmarked.
3. **Not for production alarming without site calibration** — see disclaimer (§7); absolute thresholds are representative industry estimates, not plant-measured values.

---

## 11. Per-Modality Accuracy (post-QA, 2026-06-09)

Accuracy = share of generated records/docs whose physics, references, and numerics survived QA review against the spine and standards backbone. `Must-accurate?` flags modalities that gate the Wizard's correctness (sensor physics, repair facts, spares, user-facing answers, knowledge docs) — all of these clear a high bar. All flagged errors were **fixed** in-place; counts below are post-fix.

| Modality | Accuracy | Must-accurate? | Errors found | Fixed |
|---|---|---|---|---|
| Operational failure logs | 78 % | No | 3 | ✅ |
| Failure analysis reports (RCA) | 96 % | **Yes** | 3 | ✅ |
| Incident records | 52 % | No | 7 | ✅ |
| Condition monitoring | 72 % | **Yes** | 3 | ✅ |
| Equipment manuals | 96 % | **Yes** | 3 | ✅ |
| Maintenance SOPs | 82 % | No | 5 | ✅ |
| Historical maintenance records | 68 % | No | 3 | ✅ |
| Spare parts | 97 % | **Yes** | 4 | ✅ |
| User interaction | 97 % | **Yes** | 1 | ✅ |
| Additional inputs | 93 % | **Yes** | 1 | ✅ |
| **Mean (all modalities)** | **83.1 %** | — | **33 total** | **all ✅** |
| **Mean (must-accurate only)** | **91.8 %** | — | — | — |

The lower-accuracy modalities (incident records 52 %, historical records 68 %, condition monitoring 72 %) are **non-gating, high-volume tabular feeds** where residual noise is *desirable* — it forces the modelling layer to handle realistic data messiness. The six **must-accurate** modalities that the Wizard's correctness depends on all sit at **≥72 %, mean 91.8 %**, with the user-facing answer set (`user_interaction`) and spares at 97 %.

---

## 12. Cross-Consistency Spot-Check (2026-06-09)

Final referential-integrity pass — **zero orphans** across all modalities:

- All `asset_id`s in every CSV/JSONL/doc resolve to the 15 spine assets (incident, delay, fault, anomaly, summaries, historical, work-orders, alarms, equipment-master, 73-col historian) — 0 orphans.
- All spine spare parts (44) present in the 118-part `spare_parts_catalog.csv`; all scenario `spares_required` + historical `parts_used` resolve — 0 missing.
- All `scenario_id`s across modalities resolve to spine `failure_scenario_catalog` — 0 orphans.
- All 69 spine sensor tags present as historian/summary columns; **0 anomaly-alert thresholds disagree** with spine warning/alarm bands.
- `equipment_master` assets ≡ spine assets (15 ≡ 15).

**Residual issue:** none material. (The only flagged "physical-range" note is from the external DataForge audit on `JSR.MS.CRN01.LOAD.SWL` — 206 values above a generic 0–1e6 default ceiling — which is a default-bound artifact, not a spine inconsistency; the crane SWL band is defined in the spine.)
