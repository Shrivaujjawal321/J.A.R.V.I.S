# Breakdown Summaries — TATA_JSR Steel Plant (Synthetic)

**Source:** `incident_records.csv` (150 incident rows, Jan 2024 – May 2025 reporting window)
**Site:** TATA_JSR (Jamshedpur reference plant — synthetic, physics-grounded)
**Spine version:** 1.0.0
**Disclaimer:** All figures are synthetic but internally consistent with the ground_truth_spine.json. No real Tata Steel proprietary data.

> **Methodology note.** All downtime and cost aggregates in this document are recomputed directly from `incident_records.csv` by the incident-block ranges shown for each month/quarter. "Total downtime" is the sum of every incident's `downtime_hours` (the actual event duration, planned + unplanned), reconciling 1:1 with the CSV; see the `maintenance_type` column for the planned/unplanned split. USD figures use 1 USD = INR 83.5. Window grand total: **150 incidents · 2,478.75 h · ₹3,920,695,000 (~$47.0 M)**.

---

## Monthly Summaries

### January 2024 (INC-0001 – INC-0006)

| Metric | Value |
|---|---|
| Incidents | 6 |
| Total downtime | 204.0 h |
| Total cost (INR) | ₹68,425,000 |
| Highest-cost event | INC-0002: HSM.F1.GBX01 gear tooth fatigue crack — ₹50,100,000 |
| Critical incidents | 1 (gear tooth fracture, SCN-038) |

January opened with two immediate high-severity rolling-mill failures. INC-0002, the catastrophic gear tooth fatigue crack on the F1 main-drive gearbox (HSM.F1.GBX01), generated the month's dominant cost (₹50.1 M) with 168 h unplanned downtime — consistent with the SCN-038 benchmark of a 7-day swap of the custom large-module gear wheel (36-week spare lead time). Root cause was tooth-root fatigue from a prior high-torque cobble event. The outer-race bearing spall on HSM.F3.WR.BRG01 (INC-0001) was the second major event: BPFO envelope crossed 3.2 g, temperature hit 102 °C, and AE reached 8 dBuV, yielding 12 h unplanned downtime and ₹7.5 M cost. The remaining four events — a descaling pump mechanical seal failure, two lower-severity conveyor idler and reheating furnace burner faults, and a caster segment roll seizure — were each resolved within 8 h using established Playbook procedures.

**Key signal:** Elevated F1 gearbox risk from cobble events; monthly oil-sample frequency inadequate.

---

### February 2024 (INC-0007 – INC-0013)

| Metric | Value |
|---|---|
| Incidents | 7 |
| Total downtime | 186.0 h |
| Total cost (INR) | ₹682,785,000 |
| Highest-cost event | INC-0008: BF.BLW.FAN01 compressor surge — ₹500,000,000 |
| Critical incidents | 3 (surge, mould breakout, wire rope) |

February was the most expensive month in Q1 2024, driven by three P1/CRITICAL incidents. INC-0008, the blast furnace turbo-blower compressor surge on BF.BLW.FAN01, was catastrophic: downstream valve slam pushed the operating point left of the surge line; the anti-surge valve (ASV) failed to open fast enough; shaft displacement reached 95 µm against the API 670 alarm threshold of 127 µm; recovery required 96 h unplanned downtime and cost ₹500 M (BF blast-air loss at ~$500k/hr). INC-0012, the Caster-1 mould breakout (CCM.MOLD.01), required full floor evacuation, 36 h cooldown/skull removal, and mould plate replacement — ₹71.8 M. INC-0011, the ladle crane wire-rope retirement on MS.LDC.CRN01 (MFL 320 mV, 14 broken wires per ISO 4309 discard criteria), cost ₹83 M including rope replacement and Competent Person recertification. Three medium-severity events (motor bearing AGC servo, descaling pump repeat) were resolved within planned windows.

**Key signal:** ASV response time and inlet-filter fouling management on BF.BLW.FAN01 must be escalated to monthly functional test. INC-0012 is the first Caster-1 mould breakout of the window — an early indicator of a potential systemic SEN/flux-quality issue.

---

### March 2024 (INC-0014 – INC-0022)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 87.0 h |
| Total cost (INR) | ₹34,900,000 |
| Highest-cost event | INC-0014: HSM.STD.R1 work-roll spall — ₹15,400,000 |
| Critical incidents | 0 |

March was characterised by a high volume of medium-severity events across multiple equipment classes. The sinter fan mass-imbalance event (INC-0018) required emergency stop and online dynamic balancing (24 h, ₹8 M). The HSM.STD.R1 work-roll spall (INC-0014) was resolved with the standard quick-change procedure (4 h, ₹15.4 M — primarily production loss). Two conveyor idler failures (INC-0013 recount falls in Feb, INC-0021 belt misalignment) and a CCM.SEG.07 spray-nozzle blockage (INC-0022) were low-severity. The F1 gearbox oil-degradation event (INC-0019) — GMF sidebands rising plus Fe at 22 ppm — was addressed with an oil change; however the underlying gear wear trajectory from the January cobble event was not fully reversed. OFB lube-nozzle blockage on HSM.F3.WR.BRG01 (INC-0016) was caught at 85 °C bearing-temp warning and resolved without a full bearing change.

**Key signal:** Increasing idler failure frequency on RM.CONV.ORE01 (three events Jan–Mar). Zone-level idler replacement programme recommended.

---

### April 2024 (INC-0023 – INC-0030)

| Metric | Value |
|---|---|
| Incidents | 8 |
| Total downtime | 97.0 h |
| Total cost (INR) | ₹132,035,000 |
| Highest-cost event | INC-0028: CCM.MOLD.01 breakout — ₹71,810,000 |
| Critical incidents | 1 (breakout) |

April's two critical events again dominated cost. INC-0028, the second major Caster-1 breakout (CCM.MOLD.01) — TC V-pattern 55 °C delta, friction 19 kN, level 13 mm — cost ₹71.8 M and 36 h downtime. INC-0029, a ladle crane hoist-gearbox wear event (MS.LDC.CRN01), confirmed GMF at 2.5 g and required 24 h out-of-service for gear inspection and replacement (₹10 M). The AGC hydraulic oil-contamination event (INC-0023) was the second CRM.AGC.SV01 servo-circuit contamination failure of the window, highlighting systematic hydraulic oil cleanliness issues. The BF turbo-blower thrust bearing overheating (INC-0025) was managed by controlled trip and pad replacement. Three medium events (EAF HPU filter, descaling pump bearing, work-roll spall) were resolved within planned windows.

**Key signal:** CCM.MOLD.01 breakout frequency (two events so far — February and April) is trending above acceptable rate; BPS calibration and mould flux quality must be audited. CRM.AGC.SV01 hydraulic contamination recurring: root cause tracing required.

---

### May 2024 (INC-0031 – INC-0040)

| Metric | Value |
|---|---|
| Incidents | 10 |
| Total downtime | 99.0 h |
| Total cost (INR) | ₹124,150,000 |
| Highest-cost event | INC-0040: MS.LDC.CRN01 wire rope — ₹83,000,000 |
| Critical incidents | 1 (wire rope) |

May's highest-cost event was another ladle crane wire-rope retirement (INC-0040; MFL 310 mV, 14 broken wires). The HSM.F1.MTR01 stator winding turn-short (INC-0031) — PI 1.4, temp 155 °C, phase imbalance 5% — required a planned motor swap and rewind (₹8.35 M, 10 h planned). The CCM.SEG.07 roll seizure (INC-0036) was the second seizure event on this segment, suggesting a chronic cooling-water blockage in the roll-bearing assembly. Two AGC servo events (INC-0037 hysteresis, INC-0039 gearbox oil oxidation) added ₹13.5 M combined. The OFB oil-film breakdown (INC-0038) and two hydraulic/oil events reflected inadequate oil-condition monitoring intervals. The conveyor cavitation event (INC-0032) was resolved without major damage.

**Key signal:** CCM.SEG.07 seizure recurring (2nd of the window). Root cause: chronic cooling blockage. Full segment cooling-circuit rebuild required. MS.LDC.CRN01 rope replacement (INC-0040) is the second of the window — assess multi-fall system for rope life improvement.

---

### June 2024 (INC-0041 – INC-0050)

| Metric | Value |
|---|---|
| Incidents | 10 |
| Total downtime | 188.0 h |
| Total cost (INR) | ₹557,525,000 |
| Highest-cost event | INC-0044: BF.BLW.FAN01 compressor surge — ₹500,000,000 |
| Critical incidents | 1 (compressor surge) |

June was the second-most expensive month in the reporting window. INC-0044, the second compressor surge on BF.BLW.FAN01 (96 h, ₹500 M), was attributed to repeated inlet guide vane positioner faults — the same root-cause domain as February. INC-0045, a severe CCM.MOLD.01 mould level instability event (level deviation 13 mm, SEN clogged), cost ₹30 M. INC-0048, sinter fan mass-imbalance shedding (1x 7.1 mm/s), added 24 h. The F3 work-roll bearing replacement (INC-0046) and descaling pump seal (INC-0050) were resolved in scheduled windows. The BF.CW.PMP02 pump bearing failure (INC-0049) was the first major BF cooling pump failure of the year.

**Key signal:** BF.BLW.FAN01 has now surged twice (Feb, Jun). Surge frequency pattern indicates structural issue with IGV control and anti-surge system: a dedicated reliability review and root-cause elimination is required before next quarter.

---

## Q1 2024 Quarterly Summary (January – March)

| Metric | Q1 2024 |
|---|---|
| Total incidents | 22 |
| Total downtime | 477.0 h |
| Total cost (INR) | ₹786,110,000 |
| Critical events | 4 |
| Top-cost asset | BF.BLW.FAN01 (₹500 M, single surge event) |
| Most frequent failure mode | outer_race_fatigue_spall_BPFO (2×) + idler_bearing_failure (2×) |

Q1 2024 was defined by two catastrophic events: the F1 gearbox tooth fatigue crack (INC-0002, ₹50.1 M, 168 h) and the blast furnace turbo-blower surge (INC-0008, ₹500 M, 96 h). The bearing spall on HSM.F3.WR.BRG01 recurred twice in the quarter (plus a lube-starvation event — three bearing-class events on the asset), pointing to systemic lubrication contamination in the OFB circuit rather than random fatigue. Wire-rope retirement on MS.LDC.CRN01 and the first mould breakout on CCM.MOLD.01 underlined Safety Class P1 vulnerabilities.

Recommendations Q2:
1. Initiate BF.BLW.FAN01 anti-surge root-cause elimination programme.
2. Reduce HSM.F3.WR.BRG01 OFB sampling interval from weekly to daily for ISO 4406 monitoring.
3. Conduct CCM.MOLD.01 BPS audit and SEN/flux-quality improvement programme.
4. Schedule RM.CONV.ORE01 zone-level idler rebuild (minimum 40 idlers A–D zones).

---

## Q2 2024 Quarterly Summary (April – June)

| Metric | Q2 2024 |
|---|---|
| Total incidents | 28 |
| Total downtime | 384.0 h |
| Total cost (INR) | ₹813,710,000 |
| Critical events | 3 |
| Top-cost asset | BF.BLW.FAN01 (₹500 M, second surge in June) |
| Most frequent failure mode | outer_race_fatigue_spall_BPFO (2×) + idler_bearing_failure (2×) |

Q2 saw a high incident count vs Q1. The second BF turbo-blower surge (INC-0044) in June repeated the February failure mode. CCM.MOLD.01 recorded another breakout (INC-0028) plus a severe mould-level-instability event (INC-0045), bringing the YTD breakout total to two. The ladle crane required a hoist-gearbox repair (INC-0029) and a wire-rope retirement (INC-0040) in the quarter. CRM.AGC.SV01 logged two further hydraulic events (INC-0023 oil contamination, INC-0037 hysteresis), pointing to a root cause in the servo oil-return filtration path. The HSM.STD.R1 roll events continued (INC-0026 work-roll spall, INC-0042 thermal-camber loss), suggesting roll journal wear or cobble frequency above design intent.

Recommendations Q3:
1. Emergency repair and redesign of BF.BLW.FAN01 ASV and IGV positioner systems.
2. CCM.MOLD.01: implement continuous mould-level model predictive control; upgrade BPS alert thresholds.
3. CRM.AGC.SV01: trace contamination source; rebuild servo return-line filter bank.
4. CCM.SEG.07: rebuild cooling circuit (fourth seizure this year anticipated in Q3 if not addressed).

---

## Monthly Summaries (July – September 2024)

### July 2024 (INC-0051 – INC-0060)

| Metric | Value |
|---|---|
| Incidents | 10 |
| Total downtime | 112.0 h |
| Total cost (INR) | ₹108,150,000 |
| Highest-cost event | INC-0060: BF.BLW.FAN01 journal bearing failure — ₹50,000,000 |
| Critical incidents | 1 (journal bearing failure) |

July's most severe event was the BF.BLW.FAN01 journal bearing failure (INC-0060): Babbitt wiping detected via shaft displacement 95 µm; 24 h controlled trip; OEM journal pads replaced (₹50 M production + repair). The ladle crane brake slip (INC-0057) — drum temp 120 °C, failed hold test — was a P1 safety incident: crane placed OOS and pad set replaced. The motor bearing spall repeat on HSM.F1.MTR01 (INC-0052, broken rotor bar; MCSA −34 dBc confirmed) was the second rotor-bar event in 2024, highlighting the VFD start-duty profile problem. The CCM.SEG.07 seizure (INC-0053) was the third on this segment in 2024, confirming the need for emergency cooling-circuit rebuild. Two more AGC servo events and recurring conveyor idler failures continued the year's trend.

---

### August 2024 (INC-0061 – INC-0069)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 81.0 h |
| Total cost (INR) | ₹116,335,000 |
| Highest-cost event | INC-0061: CCM.MOLD.01 breakout — ₹71,810,000 |
| Critical incidents | 1 (breakout) |

INC-0061 was the third Caster-1 breakout of the window — TC delta 58 °C, friction 20 kN — meeting all three BPS alarm conditions. Management escalated the mould flux and SEN quality programme to daily review. INC-0062 was the third work-roll spall on HSM.STD.R1. The BF.CW.PMP02 impeller wear event (INC-0068) required a pump pull and impeller replacement (₹3.5 M, 8 h). The descaling pump bearing collapse (INC-0063) and the SP.SINT.FAN01 bearing overheat (INC-0069 counted in August) were resolved without cascade failure.

---

### September 2024 (INC-0070 – INC-0078)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 104.5 h |
| Total cost (INR) | ₹123,550,000 |
| Highest-cost event | INC-0070: MS.LDC.CRN01 wire rope — ₹83,000,000 |
| Critical incidents | 2 (wire rope, belt rip-tear) |

The third ladle crane wire-rope retirement in 2024 (INC-0070; MFL 325 mV, 13 broken wires) cost ₹83 M and 24 h. The belt rip-tear on RM.CONV.ORE01 (INC-0078; rip detector 0 mA; 2.5 h, ₹5 M) was the first longitudinal tear event — attributed to tramp metal penetration. The HSM.STD.R1 fifth-octave chatter event (INC-0073; chock vib 10.0 mm/s alarm) required a roll-grinding frequency investigation beyond the standard roll change. The furnace refractory hot spot (INC-0074) and SEN erosion (INC-0075) added medium-severity entries.

---

## Q3 2024 Quarterly Summary (July – September)

| Metric | Q3 2024 |
|---|---|
| Total incidents | 28 |
| Total downtime | 297.5 h |
| Total cost (INR) | ₹348,035,000 |
| Critical events | 4 (journal bearing, breakout, wire rope, belt rip-tear) |
| Top-cost asset | MS.LDC.CRN01 (₹93 M, rope + gearbox combined Q3) |
| Most frequent failure mode | servo_valve_silting_spool_wear (2× on CRM.AGC.SV01) |

Q3 sustained a high incident count. The BF.BLW.FAN01 journal bearing failure (INC-0060, July) was a CRITICAL event caught before full surge, with cost and downtime comparable to a surge. CCM.MOLD.01 recorded its third breakout of the year (INC-0061, August). The ladle crane rope was retired again in September (INC-0070). CCM.SEG.07 logged its third seizure of the year (INC-0053, May–Jul window), confirming the cooling-circuit rebuild was overdue. A first longitudinal belt rip-tear on RM.CONV.ORE01 (INC-0078) added a fourth CRITICAL event.

Recommendations Q4:
1. Execute CCM.SEG.07 emergency cooling-circuit rebuild during planned caster outage.
2. Implement 6-monthly planned BF.BLW.FAN01 journal bearing inspection per API 670 schedule.
3. Reduce MS.LDC.CRN01 rope inspection interval to monthly MFL scan given high broken-wire rate.
4. Initiate root-cause elimination on HSM.STD.R1 cobble frequency to address recurring roll spall.

---

## Monthly Summaries (October – December 2024)

### October 2024 (INC-0079 – INC-0089)

| Metric | Value |
|---|---|
| Incidents | 11 |
| Total downtime | 235.0 h |
| Total cost (INR) | ₹107,825,000 |
| Highest-cost event | INC-0087: HSM.F1.GBX01 gear tooth fatigue crack — ₹50,100,000 |
| Critical incidents | 1 (gear tooth crack) |

INC-0087 was the second catastrophic gearbox failure of the year on HSM.F1.GBX01 — GMF 11 mm/s, Fe 65 ppm, chip detector alarm — requiring 168 h unplanned downtime and ₹50.1 M. The post-incident investigation identified repeated cobble loading as the root cause, consistent with INC-0002 in January. The SP.SINT.FAN01 mass-imbalance shedding (INC-0090) at 24 h added ₹8 M. The BF.BLW.FAN01 blade erosion (INC-0079) at 16 h reflected end-of-campaign performance decline. The fourth wire-rope retirement on MS.LDC.CRN01 (at Q3 boundary) continued the pattern. Belt rip-tear prevention on RM.CONV.ORE01 and AGC servo (INC-0080) were resolved per standard procedures.

---

### November 2024 (INC-0090 – INC-0098)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 118.0 h |
| Total cost (INR) | ₹123,760,000 |
| Highest-cost event | INC-0091: CCM.MOLD.01 breakout — ₹71,810,000 |
| Critical incidents | 1 (breakout) |

INC-0091 was the fourth CCM.MOLD.01 breakout of the window — TC V-pattern 53 °C, friction 18.5 kN — triggering a systemic tundish flux quality investigation. The HSM.F3.WR.BRG01 outer-race bearing spall recurred for the seventh time (INC-0092), and OFB circuit oil contamination was confirmed as the primary root cause. The HSM.F1.MTR01 insulation degradation (INC-0095; PI 1.4, winding temp 152 °C) required the third motor swap in 2024. The CCM.SEG.07 spray-nozzle blockage (INC-0097) indicated the cooling rebuild had still not been completed.

---

### December 2024 (INC-0099 – INC-0109)

| Metric | Value |
|---|---|
| Incidents | 11 |
| Total downtime | 163.0 h |
| Total cost (INR) | ₹225,960,000 |
| Highest-cost event | INC-0102: MS.LDC.CRN01 wire rope — ₹83,000,000 |
| Critical incidents | 2 (wire rope, breakout) |

December closed 2024 with another CCM.MOLD.01 breakout (INC-0103; the fifth breakout of the window) and the fourth ladle crane wire-rope retirement (INC-0102; annual MFL inspection, 310 mV, 11 broken wires). INC-0101 required a full BF.BLW.FAN01 blade set replacement after sustained erosion reduced efficiency by 15% — the largest single planned outage in Q4 at 24 h. The gearbox GMF recurrence (INC-0099) confirmed that the October cobble-reduction programme had not yet eliminated the loading root cause.

---

## Q4 2024 Quarterly Summary (October – December)

| Metric | Q4 2024 |
|---|---|
| Total incidents | 31 |
| Total downtime | 516.0 h |
| Total cost (INR) | ₹457,545,000 |
| Critical events | 4 (gear crack, 2× breakout, wire rope) |
| Top-cost asset | CCM.MOLD.01 (₹143.6 M, two breakouts Q4) |
| Most frequent failure mode | outer_race_fatigue_spall_BPFO (3×) + idler_bearing_failure (3×) |

Q4 was the highest-downtime quarter of 2024 (516.0 h). The second gearbox tooth fracture (INC-0087, ₹50.1 M) and two additional mould breakouts (INC-0091, INC-0103, ₹143.6 M combined) were the dominant cost drivers. CCM.MOLD.01 recorded five breakouts in 2024 — far above the industry benchmark of <1/quarter — representing a critical systemic failure in BPS management and mould-flux quality. HSM.F3.WR.BRG01 outer-race bearing spall occurred three times in Q4 (eight times across 2024), confirming OFB circuit contamination as a chronic root cause.

---

## Full-Year 2024 Annual Summary

| Metric | 2024 Full Year |
|---|---|
| Total incidents | 109 |
| Total downtime | 1,674.5 h |
| Total cost (INR) | ₹2,405,400,000 |
| Critical (P1/CRITICAL) events | 15 |
| Highest-cost single event | BF.BLW.FAN01 surge (×2: INC-0008 + INC-0044, ₹1,000,000,000 combined) |
| Most expensive asset class | BF.BLW.FAN01 / BF.CW line (₹1,050 M+ across surge+journal events) |
| Most frequent failure mode | outer_race_fatigue_spall_BPFO (8× on HSM.F3.WR.BRG01) |
| Highest individual event count | CCM.MOLD.01 (5 breakouts); CCM.SEG.07 (4 seizures); RM.CONV.ORE01 (8 idler failures) |

### Annual Observations

**Top 5 by cost (2024):**
1. BF.BLW.FAN01 — two compressor surges (INC-0008, INC-0044) + journal bearing (INC-0060) + blade/thrust events: ₹1,115,000,000
2. CCM.MOLD.01 — five breakouts + level/SEN events: ₹394,050,000
3. MS.LDC.CRN01 — four rope retirements + gearbox + brake: ₹346,000,000
4. HSM.F1.GBX01 — two tooth fractures + wear/oxidation: ₹127,700,000
5. CRM.AGC.SV01 — servo/hydraulic contamination events: ₹92,000,000 (tied with HSM.STD.R1 roll events ₹92,000,000)

**Chronic root causes identified:**

*(2024 occurrence counts)*

| Asset | Failure Mode | Root Cause | Occurrences |
|---|---|---|---|
| HSM.F3.WR.BRG01 | outer_race_fatigue_spall_BPFO | OFB circuit oil contamination (ISO 4406 not maintained) | 8 |
| CCM.MOLD.01 | breakout_sticking | SEN erosion + mould-flux quality + BPS false-alarm tolerance | 5 |
| CCM.SEG.07 | roll_seizure | Chronic cooling-circuit blockage (water scale) | 4 |
| BF.BLW.FAN01 | compressor_surge | IGV positioner and ASV reliability; inlet filter management | 2 |
| CRM.AGC.SV01 | servo_valve_silting_spool_wear | Servo return-line filter bypass; ISO 4406 not maintained | 4 |
| RM.CONV.ORE01 | idler_bearing_failure | End-of-life idler population; no proactive zone replacement | 8 |
| MS.LDC.CRN01 | wire_rope_fatigue_broken_wire | Rope life reduced by high-cycle intensity; inspection interval too long | 4 |

---

## Monthly Summaries (January – May 2025)

### January 2025 (INC-0110 – INC-0117)

| Metric | Value |
|---|---|
| Incidents | 8 |
| Total downtime | 174.75 h |
| Total cost (INR) | ₹552,700,000 |
| Highest-cost event | INC-0114: BF.BLW.FAN01 surge — ₹500,000,000 |
| Critical incidents | 2 (surge, belt rip-tear) |

INC-0114, the third BF turbo-blower compressor surge, occurred despite the Q3 2024 recommendations. The IGV positioner failed again, driving 96 h unplanned downtime and ₹500 M cost. This marks the third surge event in 12 months, confirming the root-cause elimination programme was still incomplete. INC-0117, a major longitudinal belt rip-tear on RM.CONV.ORE01 (8 m rip, 26 h, ₹10 M), was the second rip event and resulted in a BELT-SEC-1600 procurement order. The ladle crane hoist gearbox wear (INC-0115) required 24 h OOS and gear replacement. The CCM.MOLD.01 breakout (INC-0118, counted in February) was anticipated.

---

### February 2025 (INC-0118 – INC-0124)

| Metric | Value |
|---|---|
| Incidents | 7 |
| Total downtime | 100.0 h |
| Total cost (INR) | ₹107,160,000 |
| Highest-cost event | INC-0118: CCM.MOLD.01 breakout — ₹71,810,000 |
| Critical incidents | 1 (breakout) |

INC-0118 was the sixth CCM.MOLD.01 breakout across the reporting window. The mould copper taper deviation exceeded 3 mm, confirming worn plate as a contributing factor. INC-0119, OFB oil-film breakdown on HSM.F3.WR.BRG01 (the twelfth bearing-class event on this asset), resulted in 12 h and ₹5 M. INC-0121, sinter fan mass-imbalance shedding (SP.SINT.FAN01, 24 h, ₹8 M), was the fourth such shedding event since the blade recoating in August 2024 — indicating the hard-facing coating failed prematurely. INC-0124, winding overheat on HSM.F1.MTR01 (winding temp 155 °C), traced to VFD dv/dt harmonic heating; the fourth motor swap in 15 months.

---

### March 2025 (INC-0125 – INC-0133)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 273.0 h |
| Total cost (INR) | ₹118,725,000 |
| Highest-cost event | INC-0130: HSM.F1.GBX01 gear tooth fatigue crack — ₹50,100,000 |
| Critical incidents | 1 (gear crack) |

INC-0130 was the third catastrophic gearbox tooth fracture in 15 months (January 2024, October 2024, March 2025). The GEAR-WHL-M20 spare (36-week lead) was again not in stock; expedite procurement was initiated. INC-0131, BF.BLW.FAN01 bearing overheating (thrust bearing 103 °C, lube cooler valve stuck), required controlled shutdown and Babbitt pad inspection. INC-0132, a CCM.MOLD.01 copper plate wear event (heat-flux 0.9 MW/m² warning, taper deviation 3.5 mm), was resolved with a planned plate change (₹30 M). INC-0125, segment misalignment/bulging on CCM.SEG.07 (bulge 4.0 mm alarm), was the first misalignment event following the cooling rebuild — confirming the rebuild had addressed seizures but introduced an alignment issue.

---

### April 2025 (INC-0134 – INC-0142)

| Metric | Value |
|---|---|
| Incidents | 9 |
| Total downtime | 72.0 h |
| Total cost (INR) | ₹127,200,000 |
| Highest-cost event | INC-0141: MS.LDC.CRN01 wire rope — ₹83,000,000 |
| Critical incidents | 1 (wire rope) |

INC-0141 was the fifth wire-rope retirement across the reporting window (MFL 315 mV, 12 broken wires at discard limit per ISO 4309). April also recorded the third broken-rotor-bar event on HSM.F1.MTR01 (INC-0136; MCSA −33 dBc; VFD starting profile review initiated). INC-0134 was the sixth AGC servo silt event of the window, which was traced back to a cylinder rod seal failure as the contamination entry point — the first time the root cause was specifically identified and resolved. The CCM.SEG.07 roll-bearing failure (INC-0139) following the Q1 segment rebuild indicated bearing over-clamping at reduced force set-point.

---

### May 2025 (INC-0143 – INC-0150)

| Metric | Value |
|---|---|
| Incidents | 8 |
| Total downtime | 184.5 h |
| Total cost (INR) | ₹609,510,000 |
| Highest-cost event | INC-0143: BF.BLW.FAN01 surge — ₹500,000,000 |
| Critical incidents | 2 (surge, breakout) |

INC-0143 was the fourth BF.BLW.FAN01 compressor surge in 16 months — the inlet filter cake collapse triggered surge; shaft displacement 90 µm; 96 h unplanned downtime; ₹500 M cost. Despite the Q3 2024 and Q1 2025 recommendations, the inlet management programme had not been closed out. INC-0144, the seventh CCM.MOLD.01 breakout, was followed by a full BPS calibration audit. INC-0149, gearbox micropitting (HSM.F1.GBX01; GMF 8 mm/s, borescope-confirmed Hertzian pitting), was addressed with an EP oil friction modifier, which avoided a full gear change. INC-0150, the third BF.CW.PMP02 bearing failure, prompted a root-cause investigation tracing water hammer on the suction line.

---

## YTD 2025 Summary (January – May 2025)

| Metric | Jan–May 2025 |
|---|---|
| Total incidents | 41 |
| Total downtime | 804.25 h |
| Total cost (INR) | ₹1,515,295,000 |
| Critical events | 7 |
| Top-cost asset | BF.BLW.FAN01 (₹1,000,000,000 in two surges Jan+May) |
| Most frequent failure mode | compressor_surge, breakout_sticking, servo_valve_silting_spool_wear, idler_bearing_failure (2× each YTD) |

---

## Full Reporting Window Summary (Jan 2024 – May 2025)

| Metric | Total |
|---|---|
| **Total incident records** | **150** |
| **Total downtime** | **2,478.75 h** |
| **Total cost (INR)** | **₹3,920,695,000** |
| **Total cost (USD approx.)** | **~$47.0 M** |
| Critical events (P1/CRITICAL) | 22 |
| HIGH severity events | 81 |
| MEDIUM severity events | 41 |
| LOW severity events | 6 |

### Asset-Level Incident Count

| Asset | Incidents | % of Total |
|---|---|---|
| RM.CONV.ORE01 | 15 | 10.0% |
| HSM.F3.WR.BRG01 | 14 | 9.3% |
| RHF.ZONE.SOAK | 11 | 7.3% |
| CRM.AGC.SV01 | 11 | 7.3% |
| HSM.F1.GBX01 | 10 | 6.7% |
| CCM.SEG.07 | 10 | 6.7% |
| BF.BLW.FAN01 | 10 | 6.7% |
| MS.LDC.CRN01 | 10 | 6.7% |
| CCM.MOLD.01 | 10 | 6.7% |
| EAF.AUX.HYD01 | 10 | 6.7% |
| SP.SINT.FAN01 | 10 | 6.7% |
| HSM.STD.R1 | 9 | 6.0% |
| BF.CW.PMP02 | 9 | 6.0% |
| HSM.F1.MTR01 | 7 | 4.7% |
| HSM.DSC.PMP01 | 4 | 2.7% |

### Top 5 Costliest Failure Modes (across all assets)

| Failure Mode | Events | Total Cost (INR) |
|---|---|---|
| compressor_surge | 4 | ₹2,000,000,000 |
| breakout_sticking | 7 | ₹502,670,000 |
| wire_rope_fatigue_broken_wire | 5 | ₹415,000,000 |
| gear_tooth_fatigue_crack | 3 | ₹150,300,000 |
| work_roll_spall_flat | 6 | ₹92,400,000 |

### Maintenance Action Effectiveness Observations

1. **BF.BLW.FAN01 compressor surge:** Four events in 16 months despite three corrective actions (ASV replacement, IGV inspection, anti-surge recalibration). Root cause remains open. Estimated cumulative avoidable cost: ₹1,500 M if the Q3 2024 inlet-management programme had been implemented on schedule.

2. **CCM.MOLD.01 breakout_sticking:** Seven events across the window. Industry best-practice benchmark is <1 breakout per 1,000 heats. The BPS system provided reliable three-sensor agreement (TC V-pattern + friction + level) as a precursor in all confirmed events; no confirmed BPS misses, but high false-alarm rate noted in SCN-043. Reduction to <2/year requires systematic SEN specification tightening and flux management.

3. **HSM.F3.WR.BRG01 bearing spall:** Ten outer-race events across the window (fourteen bearing-class events on the asset in total). The AE sensor consistently provided the earliest warning (6 weeks lead), confirming it as the highest-value sensor for this failure mode. Oil-circuit root-cause analysis was deferred to Q3 2024 and completed in Q1 2025 — after most events had already occurred.

4. **MS.LDC.CRN01 wire rope:** Five retirements across the window at ₹83 M each. The MFL scan protocol per ISO 4309 detected discard criteria in all cases before load-on operations — indicating the inspection protocol is working correctly. Rope life reduction is driven by high-cycle ladle-lifting intensity. Two-fall reeving modification assessed as economically justified (estimated 40% rope life extension).

5. **CRM.AGC.SV01 servo valve silting:** Six servo-silting events across the window (eleven CRM.AGC.SV01 hydraulic events in total). Root cause identified in April 2025 (cylinder rod seal failure as contamination entry point). Prior events represented avoidable repeat failures following incomplete root-cause resolution.

---

*End of breakdown_summaries.md*
*Generated: 2026-06-09 | Dataset: steel-maintenance-flagship v1.0.0 | SYNTHETIC DATA*
