# mySHIPR — Carrier Console

Everything for the carrier-side console: the working HTML build, the client's review
and the answers to it, the Figma design system, and the audit that checks one against
the other.

**Live Figma file:** `mySHIPR — Carrier Console`
https://www.figma.com/design/ktu4OlSs8rCXEqsgHzVFVg/mySHIPR-%E2%80%94-Carrier-Console

---

## What is in here

### `01-console/`
`mySHIPR_Carrier_Console_v4.html` — the working console. Open it directly in a browser;
it needs no server. All 42 routes, the RBAC role switcher, the assignment wizard, the
record drawers, every form and every error state are live in this one file. This is the
authority on **behaviour**: validation rules, error codes, status vocabularies and
business logic all live here.

### `02-client-docs/`
- `Carrier_Console_Review_v4.pdf` — the client's review of the earlier build, and the
  requirements source. `..._extracted.txt` is the same document as plain text, which is
  easier to grep.
- `mySHIPR_Open_Items_for_Client.md` — the business questions that cannot be answered
  from the documents. These are decisions for the client, not gaps in the build.

### `03-figma/`
- **`FIGMA-GUIDE.md` — start here if you are showing the file to someone.** Written for
  a first-time Figma user: what a page, frame, component and variant are; how to open and
  test the prototype; and, in section 5, exactly where to point for each requirement the
  team lead gave (pixel perfect / responsive / component based / TMS based / clickable
  prototype). Section 7, "Known gaps", lists what is still open with a one-line answer for
  each — so nothing is a surprise if it gets asked about.
- `SPEC.md` — the brief the design was built against: tokens, component list, per-family
  font styles, acceptance checklist.
- `reference/` — the console rendered at 1440 @2x, one image per screen. These are the
  visual reference the Figma frames were matched against.
- `build-scripts/` — the code that generated the Figma file. It is not hand-drawn.
  - `subscreens/` — the current generator. `_base.js` is the renderer; `gen2.py` and
    `patch12.py` / `patch13.py` turn extracted console content into screen specs;
    `mk_*.py` assemble the runnable scripts.
  - `use-figma/` — the numbered scripts that were actually executed, in order.
  - `plugin/` — the original three-part builder (superseded by `subscreens/`, kept for
    reference).

### `04-audit/`
- **`FINDINGS.md`** — the important one. Seven adversarial critics reviewed the design
  against the console, the client review and the design-system claims. Every finding is
  marked with whether it was independently verified, rejected as wrong, fixed, or
  knowingly left open — with the reason. Read the "FINAL" section at the bottom for the
  end state.
- `CONSOLE_STATE.md` — what the console actually renders on all 42 screens, captured from
  the live DOM. This is the ground truth the design was checked against.
- `FIGMA_STATE.md` — what was actually built in Figma, block by block, frame by frame.
  Diff these two to see parity.

### `05-next-phase/`
`BUILD_BRIEF.md` — the plan for turning the Figma design into a frontend and backend:
ten vertical chunks, the per-chunk pipeline, the four critics that review each chunk, and
the definition of done. Section 8 lists the decisions still needed before work starts
(stack, repository, auth, database, scope, deploy target).

---

## Current state of the Figma file

Verified by reading the live file, not inferred:

| | |
|---|---|
| Desktop frames | 42 at 1440 — every route the console has |
| Responsive frames | 168 — each screen at 900 and 375, plus a Menu-open twin for each |
| Overlay frames | 20 — assignment wizard, record drawers, create forms, error states |
| Prototype links | 2,436 (756 desktop + 1,680 responsive), 0 failed, 0 missing |
| Component library | 40 components / 229 variants |
| Design system | 55 paint styles · 71 text styles · 76 variables |
| Style binding | 88,407 of 88,416 text nodes and 7,168 screen fills bound to styles |
| Quality checks | 0 visible placeholders · 0 frame overlap · no section clash |

## Known limits — stated plainly

- The **sidebar rail is a raw frame on every screen**, not an instance of `Sidebar/Root`.
  Changing the nav means re-running the generator, not editing one master. Worth fixing
  before the frontend build starts.
- **Equal-ratio columns reflow; the one 1.6:1 split does not.** Figma's `layoutGrow` is
  0 or 1 — it cannot express a fractional ratio, so that split is a measured width.
- **Radius and spacing tokens are derived from measured CSS**, not read from `:root` —
  the console defines 2 radii and no spacing variables. The colour values *are* 1:1.
- The audit's section H lists **25 domain and logic defects that live in the console's
  JavaScript, not in the Figma**. Several are business decisions for the client. They are
  documented rather than silently changed, and they must not be carried into the
  frontend/backend build.
